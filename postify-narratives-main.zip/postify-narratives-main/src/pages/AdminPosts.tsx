
import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { getAllPosts, createPost, updatePost, deletePost } from '../lib/api';
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { motion } from 'framer-motion';
import PostForm from '../components/admin/PostForm';
import PostList from '../components/admin/PostList';
import EmptyState from '../components/admin/EmptyState';

interface BlogPost {
  id: number;
  title: string;
  subtitle?: string;
  author: string;
  date: string;
  content: string;
  excerpt: string;
  imageUrl: string;
  category: string;
}

type FormValues = Omit<BlogPost, 'id'> & { id?: number };

const AdminPosts = () => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [currentPost, setCurrentPost] = useState<BlogPost | undefined>(undefined);
  const { toast } = useToast();
  
  const fetchPosts = async () => {
    try {
      const allPosts = await getAllPosts();
      setPosts(allPosts);
      
      // Extract unique categories
      const uniqueCategories = Array.from(
        new Set(allPosts.map(post => post.category))
      ).filter(Boolean) as string[];
      
      setCategories(uniqueCategories);
    } catch (error) {
      console.error('Error fetching posts:', error);
      toast({
        title: "Error",
        description: "Could not fetch posts",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  const handleEdit = (post: BlogPost) => {
    setCurrentPost(post);
    setIsEditing(true);
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    try {
      await deletePost(id);
      toast({
        title: "Success",
        description: "Post deleted successfully",
      });
      fetchPosts();
    } catch (error) {
      console.error('Error deleting post:', error);
      toast({
        title: "Error",
        description: "Failed to delete post",
        variant: "destructive"
      });
    }
  };

  const handleFormSubmit = async (data: FormValues) => {
    try {
      if (isEditing && data.id) {
        await updatePost(data.id, data);
        toast({
          title: "Success",
          description: "Post updated successfully",
        });
      } else {
        await createPost(data);
        toast({
          title: "Success",
          description: "Post created successfully",
        });
      }
      handleFormCancel();
      fetchPosts();
    } catch (error) {
      console.error('Error saving post:', error);
      toast({
        title: "Error",
        description: "Failed to save post",
        variant: "destructive"
      });
    }
  };

  const handleFormCancel = () => {
    setShowForm(false);
    setIsEditing(false);
    setCurrentPost(undefined);
  };

  const handleAddNewClick = () => {
    if (!showForm) {
      setCurrentPost(undefined);
      setIsEditing(false);
    }
    setShowForm(!showForm);
  };

  if (isLoading) {
    return (
      <Layout>
        <EmptyState message="Loading posts..." />
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="container px-4 py-8 md:py-12">
        <motion.div
          className="max-w-4xl mx-auto mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-4xl font-medium">Manage Blog Posts</h1>
            <Button onClick={handleAddNewClick}>
              {showForm ? "Cancel" : "Add New Post"}
            </Button>
          </div>

          {showForm && (
            <PostForm
              initialData={currentPost}
              categories={categories}
              isEditing={isEditing}
              onSubmit={handleFormSubmit}
              onCancel={handleFormCancel}
            />
          )}

          <PostList 
            posts={posts} 
            onEdit={handleEdit} 
            onDelete={handleDelete}
          />
        </motion.div>
      </section>
    </Layout>
  );
};

export default AdminPosts;
