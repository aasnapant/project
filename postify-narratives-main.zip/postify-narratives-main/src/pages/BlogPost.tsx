
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import Layout from '../components/Layout';
import { getPostById } from '../lib/api';
import { motion } from 'framer-motion';

interface BlogPost {
  id: number;
  title: string;
  subtitle?: string;
  author: string;
  date: string;
  content: string;
  imageUrl: string;
  category: string;
}

const BlogPost = () => {
  const { id } = useParams<{ id: string }>();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPost = async () => {
      try {
        if (id) {
          const postData = await getPostById(parseInt(id));
          setPost(postData);
        }
      } catch (err) {
        console.error('Error fetching post:', err);
        setError('Failed to load the post. It may not exist or has been removed.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchPost();
    // Smooth scroll to top when post changes
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [id]);

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="container flex items-center justify-center min-h-[60vh]">
          <div className="flex flex-col items-center">
            <div className="h-10 w-10 rounded-full border-4 border-primary border-t-transparent animate-spin"></div>
            <p className="mt-4 text-muted-foreground">Loading post...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (error || !post) {
    return (
      <Layout>
        <div className="container flex flex-col items-center justify-center min-h-[60vh] px-4 text-center">
          <h2 className="text-2xl font-medium mb-4">Post Not Found</h2>
          <p className="text-muted-foreground mb-8">{error || 'The post you are looking for does not exist.'}</p>
          <Link 
            to="/blog" 
            className="inline-flex items-center justify-center rounded-md text-sm font-medium h-10 px-4 py-2 bg-primary text-primary-foreground hover:bg-primary/90"
          >
            Back to Blog
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <article>
        {/* Hero Section with Image */}
        <div className="relative w-full h-[50vh] md:h-[70vh] mb-12">
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-black/10 z-[1]"></div>
          <img 
            src={post.imageUrl} 
            alt={post.title} 
            className="h-full w-full object-cover"
          />
          
          <div className="absolute inset-0 z-[2] flex flex-col justify-end container px-4 pb-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <span className="inline-flex items-center rounded-full bg-white/20 backdrop-blur-sm px-3 py-1 text-xs font-medium text-white shadow-sm mb-4">
                {post.category}
              </span>
              
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-medium text-white mb-3 tracking-tight max-w-3xl">
                {post.title}
              </h1>
              
              {post.subtitle && (
                <h2 className="text-xl md:text-2xl text-white/90 mb-6 max-w-2xl">
                  {post.subtitle}
                </h2>
              )}
              
              <div className="flex items-center text-white/80 text-sm">
                <span>{post.author}</span>
                <span className="mx-2">•</span>
                <time dateTime={post.date}>{formatDate(post.date)}</time>
              </div>
            </motion.div>
          </div>
        </div>
        
        {/* Article Content */}
        <div className="container px-4 pb-16">
          <div className="max-w-3xl mx-auto">
            <motion.div
              className="prose prose-lg max-w-none"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              dangerouslySetInnerHTML={{ __html: post.content }}
            />
            
            <motion.div 
              className="mt-16 pt-8 border-t"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <h3 className="text-xl font-medium mb-6">Share this article</h3>
              <div className="flex gap-4">
                <a href="#" className="p-2 rounded-full bg-secondary hover:bg-secondary/80 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                  </svg>
                </a>
                <a href="#" className="p-2 rounded-full bg-secondary hover:bg-secondary/80 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                  </svg>
                </a>
                <a href="#" className="p-2 rounded-full bg-secondary hover:bg-secondary/80 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                    <rect x="2" y="9" width="4" height="12"></rect>
                    <circle cx="4" cy="4" r="2"></circle>
                  </svg>
                </a>
              </div>
            </motion.div>
          </div>
        </div>
      </article>
    </Layout>
  );
};

export default BlogPost;
