
import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import BlogCard from '../components/BlogCard';
import { getAllPosts } from '../lib/api';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";

interface BlogPost {
  id: number;
  title: string;
  subtitle?: string;
  author: string;
  date: string;
  excerpt: string;
  imageUrl: string;
  category: string;
}

const AllPosts = () => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [filteredPosts, setFilteredPosts] = useState<BlogPost[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const allPosts = await getAllPosts();
        setPosts(allPosts);
        setFilteredPosts(allPosts);
        
        // Extract unique categories and explicitly cast to string[]
        const uniqueCategories = Array.from(
          new Set(allPosts.map(post => post.category))
        ) as string[];
        
        setCategories(uniqueCategories);
      } catch (error) {
        console.error('Error fetching posts:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    if (selectedCategory === 'All') {
      setFilteredPosts(posts);
    } else {
      setFilteredPosts(posts.filter(post => post.category === selectedCategory));
    }
  }, [selectedCategory, posts]);

  if (isLoading) {
    return (
      <Layout>
        <div className="container flex items-center justify-center min-h-[60vh]">
          <div className="flex flex-col items-center">
            <div className="h-10 w-10 rounded-full border-4 border-primary border-t-transparent animate-spin"></div>
            <p className="mt-4 text-muted-foreground">Loading posts...</p>
          </div>
        </div>
      </Layout>
    );
  }

  // If no posts, show a message and link to admin
  if (posts.length === 0) {
    return (
      <Layout>
        <section className="container px-4 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl font-medium mb-4">No Articles Yet</h1>
              <p className="text-muted-foreground mb-8">
                There are no blog posts available. Create your first post in the admin section.
              </p>
              <Button asChild>
                <Link to="/admin">Go to Admin</Link>
              </Button>
            </motion.div>
          </div>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="container px-4 py-8 md:py-12">
        <motion.div
          className="max-w-2xl mx-auto text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl font-medium mb-4">All Articles</h1>
          <p className="text-muted-foreground">
            Explore our collection of articles on design, typography, and minimalism.
          </p>
        </motion.div>

        <div className="flex flex-wrap justify-center gap-2 mb-12">
          <CategoryButton 
            label="All" 
            isSelected={selectedCategory === 'All'}
            onClick={() => setSelectedCategory('All')}
          />
          
          {categories.map((category) => (
            <CategoryButton 
              key={category} 
              label={category} 
              isSelected={selectedCategory === category}
              onClick={() => setSelectedCategory(category)}
            />
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPosts.map((post, index) => (
            <BlogCard key={post.id} post={post} index={index} />
          ))}
        </div>

        {filteredPosts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No posts found in this category.</p>
          </div>
        )}
      </section>
    </Layout>
  );
};

interface CategoryButtonProps {
  label: string;
  isSelected: boolean;
  onClick: () => void;
}

const CategoryButton: React.FC<CategoryButtonProps> = ({ label, isSelected, onClick }) => (
  <button
    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
      isSelected 
        ? 'bg-primary text-primary-foreground' 
        : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
    }`}
    onClick={onClick}
  >
    {label}
  </button>
);

export default AllPosts;
