
import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import FeaturedPost from '../components/FeaturedPost';
import BlogCard from '../components/BlogCard';
import { getFeaturedPosts, getAllPosts } from '../lib/api';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";

interface BlogPost {
  id: number;
  title: string;
  subtitle?: string;
  author: string;
  date: string;
  excerpt: string;
  imageUrl: string;
  category: string;
}

const Index = () => {
  const [featuredPosts, setFeaturedPosts] = useState<BlogPost[]>([]);
  const [recentPosts, setRecentPosts] = useState<BlogPost[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const featured = await getFeaturedPosts();
        const allPosts = await getAllPosts();
        
        setFeaturedPosts(featured);
        setRecentPosts(allPosts.slice(0, 4));
      } catch (error) {
        console.error('Error fetching posts:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  if (isLoading) {
    return (
      <Layout>
        <div className="container flex items-center justify-center min-h-[60vh]">
          <div className="flex flex-col items-center">
            <div className="h-10 w-10 rounded-full border-4 border-primary border-t-transparent animate-spin"></div>
            <p className="mt-4 text-muted-foreground">Loading posts...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      {featuredPosts.length > 0 ? (
        <section className="container px-4 mb-16 md:mb-24">
          <FeaturedPost post={featuredPosts[0]} />
        </section>
      ) : (
        <section className="container px-4 py-16 mb-16 md:mb-24">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-medium mb-4">Welcome to the Blog</h2>
            <p className="text-muted-foreground mb-8">
              There are no posts yet. Create your first post in the admin section.
            </p>
            <Button asChild>
              <Link to="/admin">Go to Admin</Link>
            </Button>
          </div>
        </section>
      )}

      {recentPosts.length > 0 ? (
        <section className="container px-4 mb-16 md:mb-24">
          <div className="flex flex-col md:flex-row justify-between items-baseline mb-10 md:mb-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Latest Posts</span>
              <h2 className="text-3xl font-medium mt-2">Fresh perspectives</h2>
            </motion.div>
            
            <Link 
              to="/blog" 
              className="inline-flex items-center mt-4 md:mt-0 text-sm font-medium transition-colors hover:text-primary/80"
            >
              View all posts
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1"
              >
                <path d="M5 12h14"></path>
                <path d="m12 5 7 7-7 7"></path>
              </svg>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recentPosts.map((post, index) => (
              <BlogCard key={post.id} post={post} index={index} />
            ))}
          </div>
        </section>
      ) : null}

      <section className="container px-4 mb-16 md:mb-24">
        <div className="bg-muted rounded-2xl p-8 md:p-12">
          <div className="max-w-2xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-2xl md:text-3xl font-medium mb-4">Subscribe to our newsletter</h2>
              <p className="text-muted-foreground mb-8">
                Stay updated with the latest articles, design trends, and insights delivered directly to your inbox.
              </p>
              
              <form className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                />
                <button className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2 bg-primary text-primary-foreground hover:bg-primary/90">
                  Subscribe
                </button>
              </form>
              
              <p className="text-xs text-muted-foreground mt-4">
                By subscribing, you agree to our Privacy Policy and consent to receive updates.
              </p>
            </motion.div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
