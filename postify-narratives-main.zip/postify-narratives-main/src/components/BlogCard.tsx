
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

interface BlogPost {
  id: number;
  title: string;
  subtitle?: string;
  author: string;
  date: string;
  excerpt: string;
  imageUrl: string;
  category: string;
}

interface BlogCardProps {
  post: BlogPost;
  index?: number;
}

const BlogCard: React.FC<BlogCardProps> = ({ post, index = 0 }) => {
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <motion.article 
      className="group relative flex flex-col overflow-hidden rounded-lg border border-border/50 bg-card hover:border-border transition-all duration-300"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
      whileHover={{ y: -5 }}
    >
      <Link to={`/blog/${post.id}`} className="absolute inset-0 z-10" aria-label={post.title}></Link>
      
      <div className="relative aspect-[16/9] overflow-hidden">
        <span className="absolute top-4 left-4 z-20 inline-flex items-center rounded-full bg-white/90 backdrop-blur-sm px-3 py-1 text-xs font-medium text-foreground shadow-sm">
          {post.category}
        </span>
        <div className="absolute inset-0 bg-gradient-to-t from-black/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        <img 
          src={post.imageUrl} 
          alt={post.title} 
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
      </div>
      
      <div className="flex flex-col flex-1 p-6">
        <div className="flex items-center text-sm text-muted-foreground mb-3">
          <span>{post.author}</span>
          <span className="mx-2">•</span>
          <time dateTime={post.date}>{formatDate(post.date)}</time>
        </div>
        
        <h3 className="text-xl font-medium tracking-tight mb-2 group-hover:text-primary/90 transition-colors">
          {post.title}
        </h3>
        
        {post.subtitle && (
          <h4 className="text-sm font-medium text-muted-foreground mb-3">
            {post.subtitle}
          </h4>
        )}
        
        <p className="text-muted-foreground text-sm leading-relaxed mb-4 line-clamp-3">
          {post.excerpt}
        </p>
        
        <div className="mt-auto pt-3">
          <span className="inline-flex items-center text-sm font-medium text-foreground transition-colors group-hover:text-primary">
            Read more
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1"
            >
              <path d="M5 12h14"></path>
              <path d="m12 5 7 7-7 7"></path>
            </svg>
          </span>
        </div>
      </div>
    </motion.article>
  );
};

export default BlogCard;
