
import React from 'react';
import { Button } from "@/components/ui/button";

interface BlogPost {
  id: number;
  title: string;
  subtitle?: string;
  author: string;
  date: string;
  content: string;
  excerpt: string;
  imageUrl: string;
  category: string;
}

interface PostListProps {
  posts: BlogPost[];
  onEdit: (post: BlogPost) => void;
  onDelete: (id: number) => void;
}

const PostList: React.FC<PostListProps> = ({ posts, onEdit, onDelete }) => {
  return (
    <div className="bg-card rounded-lg border border-border overflow-hidden">
      <div className="p-4 bg-muted">
        <h2 className="font-medium">All Posts ({posts.length})</h2>
      </div>
      <div className="divide-y divide-border">
        {posts.map((post) => (
          <div key={post.id} className="p-4 flex flex-col md:flex-row md:items-center justify-between">
            <div className="flex-1 min-w-0 mb-4 md:mb-0 md:mr-4">
              <h3 className="text-lg font-medium truncate">{post.title}</h3>
              <div className="flex items-center text-sm text-muted-foreground mt-1">
                <span>{post.author}</span>
                <span className="mx-2">•</span>
                <time dateTime={post.date}>{new Date(post.date).toLocaleDateString()}</time>
                <span className="mx-2">•</span>
                <span>{post.category}</span>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" onClick={() => onEdit(post)}>
                Edit
              </Button>
              <Button variant="destructive" size="sm" onClick={() => onDelete(post.id)}>
                Delete
              </Button>
            </div>
          </div>
        ))}
        
        {posts.length === 0 && (
          <div className="p-8 text-center text-muted-foreground">
            No posts found. Create your first post by clicking the "Add New Post" button.
          </div>
        )}
      </div>
    </div>
  );
};

export default PostList;
