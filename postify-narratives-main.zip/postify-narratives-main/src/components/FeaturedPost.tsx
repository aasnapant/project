
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

interface BlogPost {
  id: number;
  title: string;
  subtitle?: string;
  author: string;
  date: string;
  excerpt: string;
  imageUrl: string;
  category: string;
}

interface FeaturedPostProps {
  post: BlogPost;
}

const FeaturedPost: React.FC<FeaturedPostProps> = ({ post }) => {
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <motion.div 
      className="relative h-[500px] md:h-[600px] rounded-2xl overflow-hidden group"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
    >
      <Link to={`/blog/${post.id}`} className="absolute inset-0 z-10" aria-label={post.title}></Link>
      
      {/* Background Image with Gradient Overlay */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/50 to-black/20 z-[1]"></div>
        <img 
          src={post.imageUrl} 
          alt={post.title} 
          className="h-full w-full object-cover transition-transform duration-10000 ease-in-out group-hover:scale-105"
        />
      </div>
      
      {/* Content Overlay */}
      <div className="absolute inset-0 z-[2] flex flex-col justify-end p-8 md:p-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <span className="inline-flex items-center rounded-full bg-white/20 backdrop-blur-sm px-3 py-1 text-xs font-medium text-white shadow-sm mb-4">
            {post.category}
          </span>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-medium text-white mb-3 tracking-tight">
            {post.title}
          </h2>
          
          {post.subtitle && (
            <h3 className="text-xl md:text-2xl text-white/80 mb-4">
              {post.subtitle}
            </h3>
          )}
          
          <p className="text-white/80 mb-6 max-w-xl line-clamp-3 md:line-clamp-none">
            {post.excerpt}
          </p>
          
          <div className="flex items-center text-white/70 text-sm">
            <span>{post.author}</span>
            <span className="mx-2">•</span>
            <time dateTime={post.date}>{formatDate(post.date)}</time>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default FeaturedPost;
